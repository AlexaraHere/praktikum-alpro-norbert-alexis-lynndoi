celsius_f = lambda c: (9/5) * c + 32 
celsius_r = lambda c: 0.8 * c

c = int(input("ya "))
print (celsius_f(c), celsius_r(c))