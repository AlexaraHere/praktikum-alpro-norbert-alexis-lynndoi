# def dua_kali_nampil(a):
#     print(a)
#     print(a)
# dua_kali_nampil("haii!")

def tetot(angka1, angka2):
    if angka1 - angka2 == 0:
        return "wow"
    else:
        return "jelek"
print(tetot(angka2=10, angka1=10))