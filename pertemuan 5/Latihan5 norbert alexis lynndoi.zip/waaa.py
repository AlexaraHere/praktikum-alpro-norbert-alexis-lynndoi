def angka_one_to_tri(a, b, c):
    print("a: ",a)
    print("b: ",b)
    print("c: ",c)
    print("a+a: ",a+a)
    print("a+b: ",a+b)
    print("a+c: ",a+c)
angka_one_to_tri(b=30, c=40, a=20)

# def tetot(angka1, angka2=10):
#     if angka1 - angka2 == 0:
#         return "wow"
#     else:
#         return "jelek"
# print(tetot(angka1=10, angka2=20)) 